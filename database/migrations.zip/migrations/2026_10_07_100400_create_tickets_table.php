<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Tabel 5: tickets — transaksi utama aduan (tanpa auto-expire).
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tickets', function (Blueprint $table) {
            $table->id();
            $table->string('ticket_number', 30)->unique(); // TKT-YYYYMM-XXXX

            $table->foreignId('faculty_id')->constrained('faculties')->restrictOnDelete();

            $table->string('title', 200);
            $table->text('description');

            // Hanya 4 status (status 'kedaluwarsa' dihapus di v6.0)
            $table->enum('status', ['menunggu', 'diproses', 'selesai', 'ditolak'])->default('menunggu');
            $table->text('rejection_reason')->nullable(); // wajib diisi jika status = ditolak

            // Dua relasi ke tabel users yang SAMA, dengan peran berbeda
            $table->foreignId('reporter_id')->constrained('users')->restrictOnDelete(); // pembuat tiket
            $table->foreignId('handler_id')->nullable()->constrained('users')->nullOnDelete(); // staff penangan

            $table->foreignId('category_id')->constrained('categories')->restrictOnDelete();

            // SNAPSHOT SLA: disalin dari categories.sla_hours saat tiket dibuat
            $table->unsignedInteger('sla_target_hours');

            $table->timestamp('first_responded_at')->nullable();
            $table->timestamp('resolved_at')->nullable();
            $table->timestamps();

            // Index untuk mempercepat filter antrean & dashboard
            $table->index(['faculty_id', 'status']);
            $table->index(['category_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tickets');
    }
};
