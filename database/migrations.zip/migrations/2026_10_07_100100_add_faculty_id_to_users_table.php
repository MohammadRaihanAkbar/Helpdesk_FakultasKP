<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Menambahkan faculty_id ke tabel users.
 *
 * Kenapa terpisah? Migration users berjalan PALING AWAL (bawaan Laravel),
 * sedangkan foreign key hanya bisa dibuat jika tabel tujuannya (faculties) sudah ada.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // NULL untuk Super Admin & End-User; diisi untuk Staff & Admin Fakultas
            $table->foreignId('faculty_id')
                ->nullable()
                ->after('role')
                ->constrained('faculties')
                ->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropConstrainedForeignId('faculty_id');
        });
    }
};
